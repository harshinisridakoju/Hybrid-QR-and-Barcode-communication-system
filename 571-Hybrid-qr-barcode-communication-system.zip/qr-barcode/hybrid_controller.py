import cv2
import numpy as np

def perform_action(command):
    print(f"⚙️ Executing Command: {command}")
    if command == "TURN_ON_MONITOR":
        print("💡 Monitor turned ON (simulated)")
    elif command == "TURN_OFF_MONITOR":
        print("🌙 Monitor turned OFF (simulated)")
    elif command == "BRIGHTNESS_UP":
        print("🔆 Brightness increased (simulated)")
    elif command == "HELLO_WORLD":
        print("👋 Hello from the Hybrid System!")
    else:
        print("❓ Unknown command (simulated)")

def start_hybrid_controller():
    cap = cv2.VideoCapture(0)
    seen = set()
    qr_detector = cv2.QRCodeDetector()

    print("📷 Hybrid Controller Started — show QR or Barcode to execute command.")
    print("Press 'q' to quit.")

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        # === QR CODE DETECTION ===
        qr_data, qr_points, _ = qr_detector.detectAndDecode(frame)
        if qr_points is not None:
            qr_points = qr_points[0].astype(int)
            for i in range(len(qr_points)):
                cv2.line(frame, tuple(qr_points[i]), tuple(qr_points[(i + 1) % len(qr_points)]), (0, 255, 0), 2)
            if qr_data and qr_data not in seen:
                perform_action(qr_data)
                seen.add(qr_data)
            if qr_data:
                cv2.putText(frame, qr_data, (qr_points[0][0], qr_points[0][1] - 10),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.9, (255, 0, 0), 2)

        # === SIMPLE 1D BARCODE VISUAL DETECTION ===
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        blur = cv2.GaussianBlur(gray, (5,5), 0)
        _, thresh = cv2.threshold(blur, 100, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

        contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        for cnt in contours:
            x, y, w, h = cv2.boundingRect(cnt)
            aspect_ratio = w / float(h)
            # Filter for long rectangles that look like barcodes
            if w > 50 and h > 20 and aspect_ratio > 2.5:
                key = f"BARCODE_{x}_{y}"  # Unique key for this rectangle
                if key not in seen:
                    perform_action("BARCODE_DETECTED")
                    seen.add(key)
                cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 0, 255), 2)
                cv2.putText(frame, "1D Barcode", (x, y - 10),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)

        cv2.imshow("Hybrid QR + Barcode Controller", frame)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    start_hybrid_controller()