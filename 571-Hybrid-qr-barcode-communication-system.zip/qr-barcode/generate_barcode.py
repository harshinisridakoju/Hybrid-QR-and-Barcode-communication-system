import barcode
from barcode.writer import ImageWriter

# Sample data to encode
codes = ["1234567890", "9876543210", "COMMAND_ON", "COMMAND_OFF"]

for code in codes:
    ean = barcode.get('code128', code, writer=ImageWriter())
    filename = ean.save(code)

print("✅ Barcodes generated successfully!")