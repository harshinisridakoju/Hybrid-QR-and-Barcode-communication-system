import qrcode

# Commands or messages to encode
messages = ["HELLO_WORLD", "TURN_ON_MONITOR", "TURN_OFF_MONITOR", "BRIGHTNESS_UP"]

for msg in messages:
    qr = qrcode.make(msg)
    qr.save(f"{msg}.png")

print("✅ QR codes generated successfully!")