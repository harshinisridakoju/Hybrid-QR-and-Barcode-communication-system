import cv2
import numpy as np

# Initialize webcam
cap = cv2.VideoCapture(0)
if not cap.isOpened():
    print("❌ Cannot open webcam.")
    exit()

# OpenCV QR code detector
qr_detector = cv2.QRCodeDetector()

print("📷 Hybrid QR + Barcode scanner started. Press 'q' to quit.")

while True:
    ret, frame = cap.read()
    if not ret:
        break

    # === QR CODE DETECTION ===
    qr_data, qr_points, _ = qr_detector.detectAndDecode(frame)
    if qr_points is not None:
        qr_points = qr_points[0].astype(int)
        for i in range(len(qr_points)):
            cv2.line(frame, tuple(qr_points[i]), tuple(qr_points[(i + 1) % len(qr_points)]), (0, 255, 0), 2)
        if qr_data:
            cv2.putText(frame, qr_data, (qr_points[0][0], qr_points[0][1] - 10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.8, (255, 0, 0), 2)
            print(f"🧩 QR Detected: {qr_data}")

    # === 1D BARCODE VISUAL DETECTION ===
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    blur = cv2.GaussianBlur(gray, (5,5), 0)
    _, thresh = cv2.threshold(blur, 100, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

    # Find contours
    contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    for cnt in contours:
        x, y, w, h = cv2.boundingRect(cnt)
        # Filter based on aspect ratio to detect barcodes
        aspect_ratio = w / float(h)
        if w > 50 and h > 20 and aspect_ratio > 2.5:  # Typical barcode shape
            cv2.rectangle(frame, (x, y), (x+w, y+h), (0, 0, 255), 2)
            cv2.putText(frame, "1D Barcode", (x, y - 10),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 255), 2)
            print(f"📦 Barcode Detected at x:{x}, y:{y}, w:{w}, h:{h}")

    cv2.imshow("Hybrid QR + Barcode Scanner", frame)

    if cv2.waitKey(1) & 0xFF == ord("q"):
        break

cap.release()
cv2.destroyAllWindows()
print("🛑 Scanner stopped.")